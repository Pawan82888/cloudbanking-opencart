<?php
use Omnipay\Omnipay;

class ControllerExtensionPaymentCloudbanking extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/cloudbanking');
		
		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		$this->load->model('extension/payment/cloudbanking');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('payment_cloudbanking', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['authkey'])) {
			$data['error_authkey'] = $this->error['authkey'];
		} else {
			$data['error_authkey'] = '';
		}

		if (isset($this->error['api_version'])) {
			$data['error_api_version'] = $this->error['api_version'];
		} else {
			$data['error_api_version'] = '';
        }
        
        if (isset($this->error['customer_id'])) {
			$data['error_customer_id'] = $this->error['customer_id'];
		} else {
			$data['error_customer_id'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/cloudbanking', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/cloudbanking', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->post['payment_cloudbanking_authkey'])) {
			$data['payment_cloudbanking_authkey'] = $this->request->post['payment_cloudbanking_authkey'];
		} else {
			$data['payment_cloudbanking_authkey'] = $this->config->get('payment_cloudbanking_authkey');
		}

		if (isset($this->request->post['payment_cloudbanking_api_version'])) {
			$data['payment_cloudbanking_api_version'] = $this->request->post['payment_cloudbanking_api_version'];
		} else {
			$data['payment_cloudbanking_api_version'] = $this->config->get('payment_cloudbanking_api_version');
        }
        
        if (isset($this->request->post['payment_cloudbanking_customer_id'])) {
			$data['payment_cloudbanking_customer_id'] = $this->request->post['payment_cloudbanking_customer_id'];
		} else {
			$data['payment_cloudbanking_customer_id'] = $this->config->get('payment_cloudbanking_customer_id');
		}

		if (isset($this->request->post['payment_cloudbanking_method'])) {
			$data['payment_cloudbanking_method'] = $this->request->post['payment_cloudbanking_method'];
		} else {
			$data['payment_cloudbanking_method'] = $this->config->get('payment_cloudbanking_method');
		}

		if (isset($this->request->post['payment_cloudbanking_order_status_id'])) {
			$data['payment_cloudbanking_order_status_id'] = $this->request->post['payment_cloudbanking_order_status_id'];
		} else {
			$data['payment_cloudbanking_order_status_id'] = $this->config->get('payment_cloudbanking_order_status_id');
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['payment_cloudbanking_status'])) {
			$data['payment_cloudbanking_status'] = $this->request->post['payment_cloudbanking_status'];
		} else {
			$data['payment_cloudbanking_status'] = $this->config->get('payment_cloudbanking_status');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/cloudbanking', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/cloudbanking')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['payment_cloudbanking_authkey']) {
			$this->error['authkey'] = $this->language->get('error_authkey');
		}

		if (!$this->request->post['payment_cloudbanking_api_version']) {
			$this->error['api_version'] = $this->language->get('error_api_version');
        }
        
        if (!$this->request->post['payment_cloudbanking_customer_id']) {
			$this->error['customer_id'] = $this->language->get('error_customer_id');
		}

		return !$this->error;
	}

	public function gateway_instance(){
        $gateway = Omnipay::create('CloudBanking');
        $gateway->setAuthkey( $this->config->get('payment_cloudbanking_authkey') );
        $gateway->setApiVersion(  $this->config->get('payment_cloudbanking_api_version') );
        $gateway->setCustomerReference(  $this->config->get('payment_cloudbanking_customer_id') );
        return $gateway;
    }
	// To Refund Money 
	public function refund() {
		$order_id=$_POST;
		
		$this->load->language('extension/payment/cloudbanking');

		$json = array();
		$order=$order_id['order_id'];

		$gateway = $this->gateway_instance();

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cloudbanking_card` WHERE `order_id` = '" . $order . "' LIMIT 1");
		$cardToken=$query->row['cardtoken'];                           // To Get Card Token
		$transactionId=$query->row['banktransation_id'];              // To Get Transaction Id
		
		$refundRequest = $gateway->refund(array(	  
			'cardReference' 		=> $cardToken,
			'transactionReference'	=> $transactionId,
		));
		$refundResponse = $refundRequest->send();
		if ($refundResponse->isSuccessful()) {
			$json['success'] = $this->language->get('text_refunds_success');
		}
		else {
			$json['error'] = $refundResponse->getMessage();
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function order() {
		
		$this->load->model('extension/payment/cloudbanking');
		$cloudbanking_order=[];
		$cloudbanking_order = $this->model_extension_payment_cloudbanking->getOrder($this->request->get['order_id']);
		$order_id = $this->request->get['order_id'];
		if ($order_id) {
			$amount = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE `order_id` = '" . (int)$order_id . "'AND title='total' LIMIT 1");
			$this->load->language('extension/payment/cloudbanking');
			$cloudbanking_order['payment_method'] = 'Card';
			$cloudbanking_order['text_column_total'] = $amount->row['value'];
		
			$transaction['type'] = 'Payment';

			$data['cloudbanking_order'] = $cloudbanking_order;

			$data['order_id'] = $this->request->get['order_id'];

			$data['user_token'] = $this->request->get['user_token'];

			return $this->load->view('extension/payment/cloudbanking_order',$data);
		}
		
	}
}
