<?php

use Omnipay\Common\CreditCard;
use Omnipay\Omnipay;



class ControllerExtensionPaymentCloudbanking extends Controller {
	public function index() {
        
        $this->load->language('extension/payment/cloudbanking');
        
       
        $data['months'] = array();

		for ($i = 1; $i <= 12; $i++) {
			$data['months'][] = array(
				'text'  => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
				'value' => sprintf('%02d', $i)
			);
		}

		$today = getdate();

		$data['year_expire'] = array();

		for ($i = $today['year']; $i < $today['year'] + 11; $i++) {
			$data['year_expire'][] = array(
				'text'  => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
				'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
			);
		}

		return $this->load->view('extension/payment/cloudbanking', $data);
	}

	public function send() {
        
		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        
        $gateway = $this->gateway_instance();
        $card = $this->createcard($order_info);
        $gateway->setParameter('card', $card);

        $gateway->setParameter('card', $card);
		$createCardRequest = $gateway->createCard();
        $cardCreateResponse = $createCardRequest->send();
        
        if ($cardCreateResponse->isSuccessful()) {
			// Process transaction
			$cardToken = $cardCreateResponse->getToken();
            $amount= $this->currency->format($order_info['total'], $order_info['currency_code'], 1.00000, false);
			$transaction = $gateway->purchase(array(	  
					'cardReference' 		=> $cardToken,
					'amount'     			=> $amount,
					'transactionId'			=> $order_info['order_id'],
            ));
            
			$response = $transaction->send();
			if ($response->isSuccessful()) {
				// echo "Purchase transaction was successful!\n";
				$banktransactionid = $response->getTransactionReference();
				$this->model_checkout_order->addOrderHistory($this->session->data['order_id'], $this->config->get('payment_cloudbanking_order_status_id'));
                
                $this->db->query("
                CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cloudbanking_card` (
                  `order_id` INT ,
                  `banktransation_id` INT ,
                  `cardtoken` VARCHAR(500),
                  PRIMARY KEY (`order_id`)
                ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");
    
                $banktransaction_id=$response->getTransactionReference();
                $cardtoken=$response->getCardReference();
                $order_id=$order_info['order_id'];
                $this->db->query("INSERT INTO `" . DB_PREFIX . "cloudbanking_card` SET `order_id` = '" . $order_id . "', `banktransation_id` = '" . $banktransaction_id . "', `cardtoken` = '" . $cardtoken . "'");
                
                $json['redirect'] = $this->url->link('checkout/success');
			}
			else{
				$json['error'] = 'Empty Gateway Response';
                
                $this->log->write('CLOUDBANKING ERROR: Empty Gateway Response');
			}
		}
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
    }
    //create gateway object
    public function gateway_instance(){
        $gateway = Omnipay::create('CloudBanking');
        $gateway->setAuthkey( $this->config->get('payment_cloudbanking_authkey') );
        $gateway->setApiVersion(  $this->config->get('payment_cloudbanking_api_version') );
        $gateway->setCustomerReference(  $this->config->get('payment_cloudbanking_customer_id') );
        return $gateway;
    }
    //create card for gateway
    public function createcard($order_info){

        $card = new CreditCard();
    
        // Card details
        $card->setNumber(str_replace(' ', '', $this->request->post['cc_number']));
        $card->setExpiryYear($this->request->post['cc_expire_date_year']);
        $card->setExpiryMonth($this->request->post['cc_expire_date_month']);
        $card->setCvv($this->request->post['cc_cvv2']);
        $card->setEmail($order_info['email']);

        // Billing details
        $card->setBillingFirstName(html_entity_decode($order_info['payment_firstname'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingLastName(html_entity_decode($order_info['payment_lastname'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingAddress1(html_entity_decode($order_info['payment_address_1'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingCity(html_entity_decode($order_info['payment_city'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingCountry(html_entity_decode($order_info['payment_country'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingState(html_entity_decode($order_info['payment_zone'], ENT_QUOTES, 'UTF-8'));
        $card->setBillingPhone( $order_info['telephone']);
        $card->setBillingPostcode(html_entity_decode($order_info['payment_postcode'], ENT_QUOTES, 'UTF-8'));
      
        // Shipping details
        $card->setShippingFirstName(html_entity_decode($order_info['shipping_firstname'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingLastName(html_entity_decode($order_info['shipping_lastname'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingAddress1(html_entity_decode($order_info['shipping_address_1'], ENT_QUOTES, 'UTF-8') . ' ' . html_entity_decode($order_info['shipping_address_2'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingCity(html_entity_decode($order_info['shipping_city'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingCountry(html_entity_decode($order_info['shipping_country'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingState(html_entity_decode($order_info['shipping_zone'], ENT_QUOTES, 'UTF-8'));
        $card->setShippingPostcode(html_entity_decode($order_info['shipping_postcode'], ENT_QUOTES, 'UTF-8'));
        return $card;
    }
}